#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <windows.h>
#include <glut.h>
#define pi (2*acos(0.0))

double x,x1,x2,x3,x4,x5;
int level = 0,score=0;
const int font3=(int)GLUT_BITMAP_8_BY_13;
const int font2=(int)GLUT_BITMAP_HELVETICA_18 ;
int gameOverFlag = 0;

void renderBitmapString(float x, float y, void *font,const char *string){
    const char *c;
    glRasterPos2f(x, y);
    for (c=string; *c != '\0'; c++) {
        glutBitmapCharacter(font, *c);
    }
}

struct point
{
	double x,y,z;
};
struct point pos,l,u,r;

void square()
{
	glBegin(GL_QUADS);{
		glVertex2f( -1, 0);
		glVertex2f( 1,0);
		glVertex2f(1,-10);
		glVertex2f(-1, -10);
	}glEnd();
}
void drawCircle(float radius_x, float radius_y)
{
	int i = 0;
	float angle1 = 0.0;
	glBegin(GL_POLYGON);
    {
		for(i = 0; i < 100; i++)
		{
			angle1 =  2*3.1416 * i / 100;
			glVertex3f (cos(angle1) * radius_x, sin(angle1) * radius_y, 0);
		}

    }

	glEnd();
}
void drawCircle1(float radius_x, float radius_y)
{
	int i = 0;
	float angle1 = 0.0;
	glBegin(GL_POLYGON);
    {
		for(i = 0; i < 100; i++)
		{
			angle1 =  3.1416 * i / 100;
			glVertex3f (cos(angle1) * radius_x, sin(angle1) * radius_y, 0);
		}
    }
	glEnd();
}

void car()
{
    glPushMatrix();
    glPushMatrix();
    glTranslatef(6,-1,0);
    glRotated(25,0,0,1);
    glScalef(0.5,.3,0);
    glColor3d(1,1,0);
    glColor3d(0,0.5,0.5);
    square();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-6,-1,0);
    glRotated(-25,0,0,1);
    glScalef(0.5,.3,0);
    glColor3d(1,1,0);
    glColor3d(0,0.5,0.5);
    square();
    glPopMatrix();
    glPushMatrix();
    glPushMatrix();
    glTranslatef(0,-15,0);
    glRotated(180,0,0,1);
    glPushMatrix();
    glColor3d(0.8,0.7,0.8);
    glBegin(GL_QUADS);
        glVertex2d(-5,1);
        glVertex2d(5,1);
        glVertex2f(3.5,-4);
        glVertex2f(-3.5,-4);
        glEnd();
    glPopMatrix();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(5.3,-7,0);
    glRotated(90,0,0,1);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4,1);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-5.3,-7,0);
    glRotated(90,0,0,1);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4,1);
    glPopMatrix();
    glColor3d(1,1,1);
    glPushMatrix();
    glTranslated(0,1,0);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4.8,1);
    glPopMatrix();
    glColor3d(0.8,0.7,0.8);
    glBegin(GL_QUADS);
        glVertex2d(-5,1);
        glVertex2d(5,1);
        glVertex2f(3.5,-4);
        glVertex2f(-3.5,-4);
        glEnd();

    //glColor3d(1,1,0);
glBegin(GL_POLYGON);
        glColor3d(0.1,0.5,0.5);glVertex2d(-4,4);//front part
        glColor3d(0.5,0,1);glVertex2d(4,4);
        glColor3d(0.5,0,0.5);glVertex2d(6,0);
        glColor3d(0,1,0.5);glVertex2d(-6,0);
    glEnd();
    //glColor3d(1,1,0);
    glBegin(GL_POLYGON);
        glColor3d(0.5,0,0.5); glVertex2d(-6,0);
        glColor3d(1,0.5,0.5); glVertex2d(-6,-12);
        glColor3d(.5,1,0.5); glVertex2d(6,-12);
        glColor3d(0.5,0.5,0.5);glVertex2d(6,0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3d(0.5,0.5,0.5);glVertex2d(-6,-12);
        glColor3d(0.5,0,1); glVertex2d(-5,-16);
        glColor3d(0.5,1,0.5);glVertex2d(5,-16);
        glColor3d(1,0.5,0.5);glVertex2d(6,-12);
    glEnd();
    glPushMatrix();
    glTranslated(0,-15,0);
    glRotated(181,0,0,1);
    drawCircle1(5,4);
    glPopMatrix();
    glPopMatrix();

}

void carr()
{

    glPushMatrix();
    glPushMatrix();
    glTranslatef(6,-1,0);
    glRotated(25,0,0,1);
    glScalef(0.5,.3,0);
    glColor3d(1,1,0);
    glColor3d(0,0.5,0.5);
    square();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-6,-1,0);
    glRotated(-25,0,0,1);
    glScalef(0.5,.3,0);
    glColor3d(1,1,0);
    glColor3d(0,0.5,0.5);
    square();
    glPopMatrix();
    glPushMatrix();
    glPushMatrix();
    glTranslatef(0,-15,0);
    glRotated(180,0,0,1);
    glPushMatrix();
    glColor3d(0.8,0.7,0.8);
    glBegin(GL_QUADS);
        glVertex2d(-5,1);
        glVertex2d(5,1);
        glVertex2f(3.5,-4);
        glVertex2f(-3.5,-4);
        glEnd();
    glPopMatrix();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(5.3,-7,0);
    glRotated(90,0,0,1);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4,1);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-5.3,-7,0);
    glRotated(90,0,0,1);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4,1);
    glPopMatrix();
    glColor3d(1,1,1);
    glPushMatrix();
    glTranslated(0,1,0);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4.8,1);
    glPopMatrix();
    glColor3d(0.8,0.7,0.8);
    glBegin(GL_QUADS);
        glVertex2d(-5,1);
        glVertex2d(5,1);
        glVertex2f(3.5,-4);
        glVertex2f(-3.5,-4);
        glEnd();
    glBegin(GL_POLYGON);
        glColor3d(0.1,0.5,0.5);glVertex2d(-4,4);//front part
        glColor3d(0.5,0,1);glVertex2d(4,4);
        glColor3d(0.5,0,0.5);glVertex2d(6,0);
        glColor3d(0,1,0.5);glVertex2d(-6,0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3d(0.5,0,0.5); glVertex2d(-6,0);
        glColor3d(1,0.5,0.5); glVertex2d(-6,-12);
        glColor3d(.5,1,0.5); glVertex2d(6,-12);
        glColor3d(0.5,0.5,0.5);glVertex2d(6,0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3d(0.5,0.5,0.5);glVertex2d(-6,-12);
        glColor3d(0.5,0,1); glVertex2d(-5,-16);
        glColor3d(0.5,1,0.5);glVertex2d(5,-16);
        glColor3d(1,0.5,0.5);glVertex2d(6,-12);
    glEnd();
    glPushMatrix();
    glTranslated(0,-15,0);
    glRotated(181,0,0,1);
    drawCircle1(6,5);
    glPopMatrix();
    glPopMatrix();
}

void main_car()
{
   glPushMatrix();
   glTranslated(0,-60,0);
   car();
   glPopMatrix();
}
void car1()
{
   glPushMatrix();
   glTranslated(0,x1,0);
   glTranslated(-26,90,0);
   glRotatef(180,0,0,1);
   glColor3d(0,0,0);
   carr();
   glPopMatrix();

}
void car2()
{
   glPushMatrix();
   glTranslated(0,x2,0);
   glTranslated(20,70,0);
   glRotatef(180,0,0,1);
   carr();
   glPopMatrix();
}
void car3()
{
   glPushMatrix();
   glTranslated(0,x3,0);
   glTranslated(-17,0,0);
   glRotatef(180,0,0,1);
   carr();
   glPopMatrix();
}
void car4()
{
   glPushMatrix();
   glTranslated(0,x4,0);
   glTranslated(25,-1,0);
   glRotatef(180,0,0,1);
   carr();
   glPopMatrix();
}

void car5()
{
   glPushMatrix();
   glTranslated(0,x5,0);
   glTranslated(0,150,0);
   glRotatef(180,0,0,1);
   carr();
   glPopMatrix();
}

void clash()
{
   if((((x1<=-150) && (x1>=-162)) && pos.x>=16) ||(((x2<=-130) && (x2>=-142 )) && pos.x<=-10) |(((x3<=-60) && (x3>=-71)) && (pos.x>=6 && pos.x<=26)) || (((x4<=-60) && (x4>=-71)) && pos.x<=-17) || (((x5<=-210) && (x5>=-222)) && ((pos.x<=0 && pos.x>=-10) ||(pos.x>=0 && pos.x<=10))))
    {
       gameOverFlag = 1;
    }
}

void tree()
{
    glColor3d(0, 1, 0);
	glBegin(GL_TRIANGLES);
        glVertex2d(-1,0);
        glVertex2d(-10,0);
        glVertex2d(-6,4);
    glEnd();
    glColor3d(0, 1, 0);
    glBegin(GL_TRIANGLES);
        glVertex2d(-6,4);
        glVertex2d(-8,4);
        glVertex2d(-4,8);
    glEnd();
    glColor3d(0, 1, 0);
    glBegin(GL_TRIANGLES);
        glVertex2d(-4,8);
        glVertex2d(-6,8);
        glVertex2d(-2,12);
    glEnd();
    glColor3d(0, 1, 0);
    glBegin(GL_TRIANGLES);
        glVertex2d(-2,12);
        glVertex2d(-4,12);
        glVertex2d(0,16);
    glEnd();
    glColor3d(0, 1, 0);
    glBegin(GL_TRIANGLES);
        glVertex2d(0,16);
        glVertex2d(4,12);
        glVertex2d(2,12);
     glEnd();
     glColor3d(0, 1, 0);
     glBegin(GL_TRIANGLES);
        glVertex2d(2,12);
        glVertex2d(6,8);
        glVertex2d(4,8);
    glEnd();
    glColor3d(0, 1, 0);
    glBegin(GL_TRIANGLES);
        glVertex2d(4,8);
        glVertex2d(8,4);
        glVertex2d(6,4);
    glEnd();
    glColor3d(0, 1, 0);
    glBegin(GL_TRIANGLES);
        glVertex2d(6,4);
        glVertex2d(10,0);
        glVertex2d(1,0);
    glEnd();
    glBegin(GL_TRIANGLES);
        glVertex2d(-3,0);
        glVertex2d(0,16);
         glVertex2d(3,0);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(-1,0);
        glVertex2d(-6,4);
        glVertex2d(-4,8);
        glVertex2d(-2,12);
        glVertex2d(0,16);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(1,0);
        glVertex2d(6,4);
        glVertex2d(4,8);
        glVertex2d(2,12);
        glVertex2d(0,16);
    glEnd();
    glColor3f(0.4,0.2,0);
    glBegin(GL_QUADS);
    {
        glVertex2d(-2,0);
        glVertex2d(-2,-12);
        glVertex2d(2,-12);
        glVertex2d(2,0);
     }
    glEnd();
}
void triangle()
{
    glColor3f(.6f, 0.3f, 0.1f); //RED TRIANGLE
    glBegin(GL_TRIANGLES);
         glVertex2d(-15,0);
         glVertex2d(15,0);
         glVertex2d(0,10);
    glEnd();
}
void hill()
{
    glPushMatrix();
    glTranslated(-47,71,0);
    triangle();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-74,71,0);
    triangle();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-100,71,0);
    triangle();
    glPopMatrix();
    glPushMatrix();
    glTranslated(47,71,0);
    triangle();
    glPopMatrix();
    glPushMatrix();
    glTranslated(74,71,0);
    triangle();
    glPopMatrix();
    glPushMatrix();
    glTranslated(100,71,0);
    triangle();
    glPopMatrix();
}

void rec1()
{
    glBegin(GL_POLYGON);
    {
		glVertex2f(-3,7);
		glVertex2f(3,7);
		glVertex2f(3, -7);
		glVertex2f(-3, -7);
	}
	glEnd();
}
void zebra()
{
    glPushMatrix();
    glTranslatef(0, x, 0);
    glPushMatrix();
    glTranslatef(0, 80, 0);
    glColor3f(0.9,0.9,0);
    rec1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0, -80, 0);
    rec1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0, 40, 0);
    rec1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0, -40, 0);
    rec1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0, 120, 0);
    rec1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0, -120, 0);
    rec1();
    glPopMatrix();
    glPushMatrix();
    rec1();
    glPopMatrix();
    glPopMatrix();
}


void road()
{
    glColor3f(0.7, 0.7, 0.7);
	glBegin(GL_QUADS);{
		glVertex2f( -50,150);
		glVertex2f( 50,150);
		glVertex2f(50,-125);
		glVertex2f(-50,-125);
	}glEnd();
}
void roadBoarder()
{
    glColor3d(1, 1, 0);
	glBegin(GL_QUADS);{
		glVertex2f( -50,150);
		glVertex2f( -50,-125);
		glVertex2f(-60,-125);
		glVertex2f(-60,150);
	}glEnd();
}

void roadBoarder2()
{
    glColor3d(1, 1, 0);
	glBegin(GL_QUADS);{
		glVertex2f( 50,150);
		glVertex2f( 50,-125);
		glVertex2f(60,-125);
		glVertex2f(60,150);
	}glEnd();
}
void trees()
{
    glPushMatrix();
    glTranslated(-105,61,0);
    glScaled(0.3,0.45,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-59,73,0);
    glScaled(0.2,0.2,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-105,72,0);
    glScaled(0.2,0.2,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-70,65,0);
    glScaled(0.3,0.4,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-65,40,0);
    glScaled(0.4,0.6,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-90,30,0);
    glScaled(0.5,0.6,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-70,-20,0);
    glScaled(0.9,1,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-80,-60,0);
    glScaled(0.8,1.5,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(105,61,0);
    glScaled(0.3,0.45,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(59,73,0);
    glScaled(0.2,0.2,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(85,72,0);
    glScaled(0.2,0.2,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(70,65,0);
    glScaled(0.3,0.4,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(65,40,0);
    glScaled(0.4,0.6,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(90,30,0);
    glScaled(0.5,0.6,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(70,-10,0);
    glScaled(0.7,0.9,0);
    tree();
    glPopMatrix();
    glPushMatrix();
    glTranslated(80,-60,0);
    glScaled(0.8,1.5,0);
    tree();
    glPopMatrix();
}
void akash1()
{
	glBegin(GL_QUADS);{
		glColor3f(0.1, .6, 0.8);glVertex2f( 0,150);
		glColor3f(.1, .6, .8);glVertex2f( 0,300);
		glColor3f(0, 0, 1);glVertex2f(-300,300);
		glColor3f(0.1, 0.6, 1);glVertex2f(-300,150);
	}glEnd();
}
void akash2()
{
     glColor3f(1, 1, 1);
	glBegin(GL_QUADS);{
		glColor3f(0.1, .6, 0.8);glVertex2f( 0,150);
		glColor3f(.1, .6, .8);glVertex2f( 0,300);
		glColor3f(0, 0, 1);glVertex2f(300,300);
		glColor3f(.1, 0.6, 1);glVertex2f(300,150);
	}glEnd();
}

void ghash1()
{
     glColor3f(0.6, 0.5, 0);
	 glBegin(GL_QUADS);{
		glColor3f(0.5, 0.7, 0);glVertex2f( -60,150);
		glColor3f(.1, .1, 0);glVertex2f( -60,-125);
		glColor3f(0.6, 0.6, 0);glVertex2f(-200,-125);
		glColor3f(0.5, 0.8, 0);glVertex2f(-200,150);
	}glEnd();
}

void ghash2()
{
     glColor3f(0.6, 0.5, 0);
	 glBegin(GL_QUADS);{
		glColor3f(0.5, 0.7, 0);glVertex2f( 60,150);
		glColor3f(0.2, 0.2, 0);glVertex2f( 60,-125);
		glColor3f(0.6, 0.8, 0);glVertex2f(200,-125);
		glColor3f(0.5, 0.8, 0);glVertex2f(200,150);
	}glEnd();
}

void carrr()
{
    glPushMatrix();
    glPushMatrix();
    glTranslatef(0,5,0);
    glColor3d(0.5,0.3,0.5);
    drawCircle(5,1);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(7,-1,0);
    glRotated(25,0,0,1);
    glScalef(0.5,.3,0);
    glColor3d(1,1,0);
    glColor3d(0.5,0.5,0.5);
    square();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-7,-1,0);
    glRotated(-25,0,0,1);
    glScalef(0.5,.3,0);
    glColor3d(1,1,0);
    glColor3d(0.5,0.5,0.5);
    square();
    glPopMatrix();
    glPushMatrix();
    glPushMatrix();
    glTranslatef(0,-15,0);
    glRotated(180,0,0,1);
    glPushMatrix();
    glColor3d(0.8,0.7,0.8);
    glBegin(GL_QUADS);
        glVertex2d(-5,1);
        glVertex2d(5,1);
        glVertex2f(3.5,-4);
        glVertex2f(-3.5,-4);
        glEnd();
    glPopMatrix();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(5.3,-7,0);
    glRotated(90,0,0,1);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4,1);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-5.3,-7,0);
    glRotated(90,0,0,1);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4,1);
    glPopMatrix();
    glColor3d(1,1,1);
    glPushMatrix();
    glTranslated(0,1,0);
    glColor3d(0.8,0.7,0.8);
    drawCircle(4.8,1);
    glPopMatrix();
    glColor3d(0.8,0.7,0.8);
    glBegin(GL_QUADS);
        glVertex2d(-5,1);
        glVertex2d(5,1);
        glVertex2f(3.5,-4);
        glVertex2f(-3.5,-4);
        glEnd();
    glBegin(GL_POLYGON);
        glColor3d(0.2,0.5,0.5);glVertex2d(-5,5);//front part
        glColor3d(0.5,0,0.8);glVertex2d(5,5);
        glColor3d(0.5,0,0.5);glVertex2d(7,0);
        glColor3d(0,1,0.5);glVertex2d(-7,0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3d(0.5,0,0.5); glVertex2d(-7,0);
        glColor3d(1,0.5,0.5); glVertex2d(-7,-12);
        glColor3d(.5,1,0.5); glVertex2d(7,-12);
        glColor3d(0.5,0.5,0.5);glVertex2d(7,0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3d(0.5,0.5,0.5);glVertex2d(-7,-12);
        glColor3d(0.5,0,1); glVertex2d(-6,-16);
        glColor3d(0.5,1,0.5);glVertex2d(6,-16);
        glColor3d(1,0.5,0.5);glVertex2d(7,-12);
    glEnd();
    glPushMatrix();
    glTranslated(0,-15,0);
    glRotated(181,0,0,1);
    drawCircle1(6,5);
    glPopMatrix();
    glPopMatrix();

}

void printS(char *string, float x, float y)
{
	glColor3f(0.9, 0.8, 0.6);
	char *c;
    glRasterPos2f(x, y);
	for (c = string; *c != '\0'; c++)
	{
	    glPushMatrix();
        glScaled(5,5,0);
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *c);
		glPopMatrix();
    }
}
void printS1(char *string, float x, float y)
{
	glColor3f(0.9, 0.2, 0.6);
	char *c;
	glRasterPos2f(x, y);
	for (c = string; *c != '\0'; c++)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
}
void rec2()
{

    glBegin(GL_POLYGON);
    {
		glColor3f(0.4,0.1,0.4);glVertex2f(-1.5,9);
		glColor3f(0.1,0.2,0.1);glVertex2f(1.5,9);
		glColor3f(0.2,0.3,0.3);glVertex2f(1.5,-9);
		glColor3f(0.5,0.1,0.4);glVertex2f(-1.5,-9);
	}
	glEnd();
}
void menu()
{
    printS("2D CAR CLASH GAME",-55,70);
    glPushMatrix();
    glTranslated(-20,13,0);
    glRotated(-175,0,0,1);
    glScalef(1,2.4,0);
    carrr();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-30,-15,0);
    glRotated(-45,0,0,1);
    glScalef(1.3,2.7,0);
    carrr();
    glPopMatrix();
    glPushMatrix();
    glTranslated(-29,0,0);
    glRotated(-15,0,0,1);
    glPushMatrix();
    glPushMatrix();
    glTranslated(0,-75,0);
    rec2();
    glPopMatrix();
    glPushMatrix();
    glTranslated(0,35,0);
    rec2();
    glPopMatrix();
    glPushMatrix();
    glTranslated(0,-35,0);
    rec2();
    glPopMatrix();
    glPushMatrix();
    glTranslated(0,-1,0);
    rec2();
    glPopMatrix();
    glPushMatrix();
    glTranslated(0,75,0);
    rec2();
    glPopMatrix();
    glBegin(GL_QUADS);
    {
		glColor3f(0.6, 0.9, 0.6);glVertex2f( -15,150);
		glColor3f(0.2, 0.5, 0.3);glVertex2f( 15,150);
		glColor3f(0.3, 0.6, 0.7);glVertex2f( 35,-150);
        glColor3f(0.1, 0.5, 0.3);glVertex2f( -35,-150);
	}glEnd();
	glBegin(GL_QUADS);
	{
		glColor3f(0, 0.2, 0.1);glVertex2f( -15,150);
		glColor3f(0.2, 0.4, 0.1);glVertex2f( -18,150);
		glColor3f(0, 0.5, 0.2);glVertex2f( -38,-150);
        glColor3f(0.1, 0.2, 0.5);glVertex2f( -35,-150);
	}glEnd();
	glBegin(GL_QUADS);
	{
		glColor3f(0, 0.2, 0.1);glVertex2f( 15,150);
		glColor3f(0.2, 0.4, 0.1);glVertex2f( 18,150);
		glColor3f(0, 0.5, 0.2);glVertex2f( 38,-150);
        glColor3f(0.1, 0.2, 0.5);glVertex2f( 35,-150);
	}glEnd();
	glPopMatrix();
    glPopMatrix();
    glPushMatrix();
    printS1("Press Space",39,33);
    printS1("Start Game",39,40);
    glTranslated(55,40,0);
    glColor3f(0.5, 0.4, 0.1);
    drawCircle(25,14);
    glPopMatrix();
    glPushMatrix();
    printS1("Press End",41,-16);
    printS1("Quit Game",40,-8);
    glTranslated(55,-10,0);
    glColor3f(0.5, 0.4, 0.1);
    drawCircle(25,14);
    glPopMatrix();

    glColor3f(0, 0, 0);
	glBegin(GL_QUADS);{
		glColor3f(0.7, 0.16, 0.96);glVertex2f( 109,90);
		glColor3f(0.8, 0.5, 0.1);glVertex2f( 25,70);
		glColor3f(0.5, 0.16, 0.96);glVertex2f( 25,-50);
        glColor3f(0.6, 0.5, 0.3);glVertex2f( 109,-70);
	}glEnd();
	glBegin(GL_QUADS);{
	    glColor3f(0.7, 0.16, 0.96);glVertex2f( 25,30);
		glColor3f(0.8, 0.5, 0.1);glVertex2f( 15,27);
		glColor3f(0.6, 0.5, 0.3);glVertex2f( 15,-7);
		glColor3f(0.5, 0.3, 0.2);glVertex2f( 25,-10);
	}glEnd();
	glBegin(GL_QUADS);{

	    glColor3f(0.18, 0.18, 0.8);glVertex2f( -109,150);
		glColor3f(0.4, 0.5, 0.1);glVertex2f( 109,150);
		glColor3f(0.6, 0.3, 0.3);glVertex2f( 109,-150);
		glColor3f(0.19, 0.5, 0.8);glVertex2f( -109,-150);
	}glEnd();
}

void keyboardListener(unsigned char key, int xx,int yy){
    double x,y,z;
    double rate = 0.01;
	switch(key){

		case ' ':
			{
            level=1;
            }
			break;
		default:
			break;
	}
}

void specialKeyListener(int key, int x,int y){
	switch(key){

		case GLUT_KEY_LEFT :
            if(pos.x<=32)
            {
                pos.x++;
            }
            break;
		case GLUT_KEY_RIGHT :
			if(pos.x>=-32)
            {
                pos.x--;
            }
			break;
			case GLUT_KEY_END :
			    {
			     exit(0);
			    }
			    break;
		default:
			break;
	}
}

void display(){

	//clear the display
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0,0,0,0);	//color black
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//load the correct matrix -- MODEL-VIEW matrix
	glMatrixMode(GL_MODELVIEW);
	//initialize the matrix
	glLoadIdentity();
	//for front page
	glPushMatrix();
	if(level==0)
    {
	glPushMatrix();
	glPushMatrix();
	gluLookAt(0,0,100,	0,0,0,	0,1,0);
    menu();
	glPopMatrix();
	glPopMatrix();
	glutSwapBuffers();
	}
	glPopMatrix();

    //for main game
    glPushMatrix();
	if(level==1)
    {
	glPushMatrix();
	//to see coming cars
	gluLookAt(0,-80,100,	0,0,0,	0,1,0);

	glPushMatrix();
    car1();
    glPopMatrix();

    glPushMatrix();
    car2();
    glPopMatrix();


    glPushMatrix();
    car3();
    glPopMatrix();

    glPushMatrix();
    car4();
    glPopMatrix();

    glPushMatrix();
    car5();
    glPopMatrix();

    glPopMatrix();

    glPushMatrix();
    glPushMatrix();

	//to see main car
	gluLookAt(pos.x,0,100,	pos.x+l.x,0,0,	0,1,0);

	clash();
    main_car();

    glPopMatrix();
    glPopMatrix();

	glPushMatrix();
	// to see trees,hill,scores
	gluLookAt(0,0,130,	0,0,0,	0,1,0);
    char buffer [50];
    sprintf (buffer, "SCORE: %d", score);
    glColor3f(0.000, 1.000, 0.000);
    renderBitmapString(80.5,95,(void *)font3,buffer);
	trees();
	hill();
	glPushMatrix();
	glTranslated(-100,105,0);
	glColor3f(0.9,0.8,0);
	drawCircle(10,10);
	glPopMatrix();
	glPopMatrix();
	//to see far road
	gluLookAt(0,-80,150,	0,0,0,	0,1,0);
	if(gameOverFlag==1)//when game over
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        printS("GAME OVER", -25, 0);
        x=0;
        char buffer2 [50];
        sprintf (buffer2, "Your Score is : %d", score);
        glColor3f(0.9, 0.2 , 0.6);
        renderBitmapString(-23 ,-10,(void *)font2,buffer2);
	}

    akash1();
    akash2();
	zebra();
	road();
	roadBoarder();
	roadBoarder2();
	ghash1();
	ghash2();
	glutSwapBuffers();
    }
    glPopMatrix();
}


//to run zebra and cars
void animate(){
    glPushMatrix();
     if(level==1)
    {
    if(x>20)
    {
       x=-20;
       score++;
    }
    x+=0.09;

    if(x1<-400)
    {
       x1=70;
    }
    x1-=0.08; // car1


    if(x2<-670) // car2
    {
       x2=90;
    }
    x2-=0.08;

    if(x3<-300) // car3
    {
       x3=150;
    }
    x3-=0.08;

    if(x4<-300) // car4
    {
       x4=150;
    }
    x4-=0.08;
    if(x5<-450) // car4
    {
       x5=5;
    }
    x5-=0.05;
}
glPopMatrix();
	glutPostRedisplay();

}

void init(){
	glClearColor(0,0,0,0);
	//load the PROJECTION matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80,	1,	1,	1000.0);
}

int main(int argc, char **argv){
    pos.x=0;
    l.x=0;
	glutInit(&argc,argv);
	glutInitWindowSize(600, 620);
	glutInitWindowPosition(0, 0);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);	//Depth, Double buffer, RGB color

	glutCreateWindow("2D Car Clash Game");
	init();
	glEnable(GL_DEPTH_TEST);	//enable Depth Testing
    glutDisplayFunc(display);
	glutIdleFunc(animate);		//what you want to do in the idle time (when no drawing is occuring)
	glutKeyboardFunc(keyboardListener);
	glutSpecialFunc(specialKeyListener);
    glutMainLoop();		//The main loop of OpenGL

	return 0;
}

